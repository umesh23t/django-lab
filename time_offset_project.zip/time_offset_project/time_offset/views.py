from django.shortcuts import render
from .models import TimeOffset

def index(request):
    current_time = TimeOffset.get_current_time()
    ahead_time = TimeOffset.get_offset_time(4)
    before_time = TimeOffset.get_offset_time(-4)
    return render(request, 'index.html', {'current_time': current_time, 'ahead_time': ahead_time, 'before_time': before_time})


# Create your views here.
