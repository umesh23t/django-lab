from django.db import models
from datetime import datetime, timedelta

class TimeOffset(models.Model):
    @classmethod
    def get_current_time(cls):
        return datetime.now()

    @classmethod
    def get_offset_time(cls, hours):
        current_time = cls.get_current_time()
        offset_time = current_time + timedelta(hours=hours)
        return offset_time

# Create your models here.
