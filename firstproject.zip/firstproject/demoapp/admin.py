from django.contrib import admin
from .models import Fruit, Student

admin.site.register(Fruit)
admin.site.register(Student)



# Register your models here.
