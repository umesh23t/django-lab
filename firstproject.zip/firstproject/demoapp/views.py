from django.shortcuts import render
from django.http import HttpResponse
from .models import Fruit, Student
# Create your views here.


def home(request):
    return HttpResponse("This is first app")
def demo(request):
    return HttpResponse("This is full stack django")
#def base(request):
 #   return HttpResponse()

def base(request):
    if request.method == "POST":
        username = request.POST.get('username')
        if username:
            return HttpResponse(f'<h1>hello {username}</h1>')
        else:
            return HttpResponse('<h1>please, enter your username</h1>')

    return render(request, "base.html")




def fruit_list(request):
    fruits = Fruit.objects.all()
    return render(request, "fruit_list.html", {'fruits': fruits})

def student_list(request):
    students = Student.objects.all()
    return render(request, "student_list.html", {'students': students})
