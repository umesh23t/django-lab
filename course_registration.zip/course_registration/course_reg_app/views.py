from django.shortcuts import render, redirect
from .models import Course, Student

def course_list(request):
    courses = Course.objects.all()
    return render(request, 'course_list.html', {'courses': courses})

def course_detail(request, course_id):
    course = Course.objects.get(pk=course_id)
    students = course.students.all()
    return render(request, 'course_detail.html', {'course': course, 'students': students})

def register_student(request, course_id):
    if request.method == 'POST':
        course = Course.objects.get(pk=course_id)
        student_name = request.POST['name']
        student_email = request.POST['email']
        student, created = Student.objects.get_or_create(name=student_name, email=student_email)
        course.students.add(student)
        return redirect('course_detail', course_id=course_id)
    else:
        return render(request, 'register_student.html', {'course_id': course_id})


# Create your views here.
